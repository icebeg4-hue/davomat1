const $ = id => document.getElementById(id);
const FINE_THRESHOLD = 4;
const pad = n => String(n).padStart(2, "0");
const today = () => { const d = new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };
const nowStr = () => { const n = new Date(); return pad(n.getHours()) + ":" + pad(n.getMinutes()); };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const fmtD = d => d.split("-").reverse().join(".");
const WHEEL_MONTHS = ["yanvar", "fevral", "mart", "aprel", "may", "iyun", "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"];
let wheelInputs = {}, activeWheelInput = null, wheelState = null, wheelScrollTimer = null;
const keyOf = r => (r.name || "").trim().toLowerCase().replace(/\s+/g, " ") + "|" + (r.cls || "").trim().toLowerCase();
const q = v => '"' + String(v).replace(/"/g, '""') + '"';

const downloadWindows = document.getElementById("downloadWindows");
if (downloadWindows) {
  downloadWindows.addEventListener("click", event => {
    const proceed = window.confirm(
      "Bu o'rnatish fayli Windows SmartScreen tomonidan vaqtincha noma'lum deb ko'rsatilishi mumkin, chunki fayl tijorat raqamli sertifikatiga ega emas.\n\n" +
      "SmartScreen oynasida:\n1. «Подробнее» ni bosing.\n2. «Выполнить в любом случае» yoki «Run anyway» ni tanlang.\n\nDavom ettirasizmi?"
    );
    if (!proceed) event.preventDefault();
  });
}

const downloadApk = document.getElementById("downloadApk");
if (downloadApk) {
  downloadApk.addEventListener("click", async event => {
    event.preventDefault();
    const url =
      "https://raw.githubusercontent.com/icebeg4-hue/davomat1/main/Maktab-Davomat.apk      ?download=1.0.7";
    try {
      const response = await fetch(url, { cache: "no-store" });
      if (!response.ok) throw new Error("APK yuklab olinmadi");
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = "Maktab-Davomat-1.0.6.apk";
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 30000);
    } catch (error) {
      window.location.href =
        "https://raw.githubusercontent.com/icebeg4-hue/davomat1/main/Maktab-Davomat.apk";
    }
  });
}

const updateWrap = document.getElementById("appUpdateWrap");
const updateStatus = document.getElementById("appUpdateStatus");
const updateButton = document.getElementById("appUpdateButton");
const forceUpdateBackdrop = document.getElementById("forceUpdateBackdrop");
const forceUpdateStatus = document.getElementById("forceUpdateStatus");
const forceUpdateButton = document.getElementById("forceUpdateButton");
const isNativeApp = Boolean(window.Capacitor?.isNativePlatform?.());
if (isNativeApp) document.body.classList.add("native-app");

async function checkAppUpdate() {
  const appUpdater = window.Capacitor?.Plugins?.AppUpdater;
  if (!window.Capacitor?.isNativePlatform?.() || !appUpdater) return;
  if (updateWrap) updateWrap.hidden = false;
  try {
    const info = await appUpdater.getInfo();
    const response = await fetch(
      "https://raw.githubusercontent.com/icebeg4-hue/davomat1/main/update.json?cache=" +
      Date.now(),
      { cache: "no-store" }
    );
    if (!response.ok) throw new Error("Yangilanish ro‘yxati ochilmadi");
    const update = await response.json();
    const currentCode = Number(info.versionCode || 0);
    if (Number(update.versionCode) > currentCode) {
      if (isNativeApp && forceUpdateBackdrop) {
        forceUpdateBackdrop.hidden = false;
        if (forceUpdateStatus) {
          forceUpdateStatus.textContent =
            "Yangi " + update.version + " versiyasi mavjud. Ilovani ishlatish uchun yangilang.";
        }
        if (forceUpdateButton) {
          forceUpdateButton.onclick = async () => {
            forceUpdateButton.disabled = true;
            forceUpdateStatus.textContent = "Yangilanish yuklanmoqda...";
            try {
              await appUpdater.downloadAndInstall({
                url: update.apkUrl + "?v=" + update.versionCode,
                sha256: update.sha256
              });
              forceUpdateStatus.textContent =
                "Yuklash tugadi. Telefon o‘rnatishni tasdiqlang.";
            } catch (error) {
              forceUpdateStatus.textContent =
                "Yangilanishni yuklab bo‘lmadi. Internetni tekshirib qayta urinib ko‘ring.";
            } finally {
              forceUpdateButton.disabled = false;
            }
          };
        }
      }
      if (updateStatus) {
        updateStatus.textContent =
          "Yangi versiya " + update.version + " mavjud." +
          (update.releaseNotes ? " " + update.releaseNotes : "");
      }
      if (updateButton) {
        updateButton.hidden = false;
        updateButton.onclick = async () => {
          updateButton.disabled = true;
          updateStatus.textContent = "Yangilanish yuklanmoqda...";
          try {
            await appUpdater.downloadAndInstall({
              url: update.apkUrl + "?v=" + update.versionCode,
              sha256: update.sha256
            });
            updateStatus.textContent =
              "Yuklash tugadi. Telefon o‘rnatishni tasdiqlang.";
          } catch (error) {
            updateStatus.textContent =
              "Yangilanishni yuklab bo‘lmadi: " +
              (error?.message || "Noma’lum xato");
          } finally {
            updateButton.disabled = false;
          }
        };
      }
    } else if (updateStatus) {
      updateStatus.textContent =
        "Ilova eng so‘nggi versiyada (" + info.versionName + ").";
    }
  } catch (error) {
    if (updateStatus) {
      updateStatus.textContent =
        "Yangilanish tekshirilmadi: " +
        (error?.message || "Internetga ulanishni tekshiring");
    }
  }
}

function activateSection(tabId, focusTab) {
  const tabs = Array.from(document.querySelectorAll(".section-tab"));
  tabs.forEach(tab => {
    const active = tab.id === tabId;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
    tab.tabIndex = active ? 0 : -1;
    $(tab.getAttribute("aria-controls")).hidden = !active;
  });
  if (focusTab) $(tabId).focus();
  window.scrollTo(0, 0);
}
const sectionTabList = document.querySelector(".section-tabs");
sectionTabList.addEventListener("click", e => {
  const tab = e.target.closest(".section-tab");
  if (tab) activateSection(tab.id, false);
});
sectionTabList.addEventListener("keydown", e => {
  const tabs = Array.from(sectionTabList.querySelectorAll(".section-tab"));
  const current = tabs.indexOf(document.activeElement);
  if (current < 0) return;
  let next = current;
  if (e.key === "ArrowRight") next = (current + 1) % tabs.length;
  else if (e.key === "ArrowLeft") next = (current + tabs.length - 1) % tabs.length;
  else if (e.key === "Home") next = 0;
  else if (e.key === "End") next = tabs.length - 1;
  else return;
  e.preventDefault();
  activateSection(tabs[next].id, true);
});

function refreshWheelDisplay(id) {
  const entry = wheelInputs[id];
  if (!entry) return;
  if (entry.input.tagName === "SELECT") {
    const option = entry.input.options[entry.input.selectedIndex];
    entry.trigger.textContent = option ? option.textContent : "";
    entry.trigger.disabled = entry.input.disabled;
    return;
  }
  const parts = entry.input.value.split(/[-:]/).map(Number);
  entry.trigger.textContent = entry.input.type === "date" ?
    pad(parts[2]) + "." + pad(parts[1]) + "." + parts[0] :
    pad(parts[0]) + ":" + pad(parts[1]);
}
function closeWheelPicker() {
  if (!activeWheelInput) return;
  const input = activeWheelInput;
  $("wheelBackdrop").hidden = true;
  document.body.classList.remove("wheel-modal-open");
  document.removeEventListener("keydown", onWheelKeydown);
  activeWheelInput = null;
  wheelState = null;
  wheelInputs[input.id].trigger.focus();
}
function onWheelKeydown(e) {
  if (e.key === "Escape") closeWheelPicker();
}
function wheelDaysInMonth() { return new Date(wheelState.year, wheelState.month, 0).getDate(); }
function renderWheelColumns() {
  const isDate = activeWheelInput.type === "date";
  const isSelect = activeWheelInput.tagName === "SELECT";
  const columns = $("wheelColumns");
  columns.classList.toggle("time-columns", !isDate && !isSelect);
  columns.classList.toggle("select-columns", isSelect);
  const defs = isDate ? [
    { key: "day", label: "Kun", values: Array.from({ length: wheelDaysInMonth() }, (_, i) => i + 1), format: pad },
    { key: "month", label: "Oy", values: Array.from({ length: 12 }, (_, i) => i + 1), format: v => WHEEL_MONTHS[v - 1] },
    { key: "year", label: "Yil", values: Array.from({ length: Math.max(new Date().getFullYear() + 2, wheelState.year) - Math.min(new Date().getFullYear() - 10, wheelState.year) + 1 }, (_, i) => Math.min(new Date().getFullYear() - 10, wheelState.year) + i), format: String }
  ] : isSelect ? [
    { key: "optionIndex", label: activeWheelInput.id.indexOf("Cls") >= 0 || activeWheelInput.id === "cls" ? "Sinf" : "O‘quvchi", values: Array.from({ length: activeWheelInput.options.length }, (_, i) => i), format: i => activeWheelInput.options[i].textContent }
  ] : [
    { key: "hour", label: "Soat", values: Array.from({ length: 24 }, (_, i) => i), format: pad },
    { key: "minute", label: "Daqiqa", values: Array.from({ length: 60 }, (_, i) => i), format: pad }
  ];
  columns.innerHTML = defs.map(def => {
    const selected = wheelState[def.key];
    return "<div class='wheel-unit'><div class='wheel-label'>" + def.label + "</div><div class='wheel-column' role='listbox' aria-label='" + def.label + "' data-key='" + def.key + "'>" +
      def.values.map((value, i) => {
        const label = String(def.format(value));
        return "<button type='button' class='wheel-item" + (value === selected ? " selected" : "") + "' role='option' aria-selected='" + (value === selected) + "' title='" + esc(label) + "' data-index='" + i + "' data-value='" + value + "'>" + esc(label) + "</button>";
      }).join("") +
      "</div></div>";
  }).join("");
  columns.querySelectorAll(".wheel-column").forEach(column => {
    const key = column.dataset.key, def = defs.find(d => d.key === key);
    column.scrollTop = def.values.indexOf(wheelState[key]) * 44;
    column.addEventListener("scroll", () => {
      clearTimeout(wheelScrollTimer);
      wheelScrollTimer = setTimeout(() => {
        if (!columns.contains(column)) return;
        const index = Math.max(0, Math.min(def.values.length - 1, Math.round(column.scrollTop / 44)));
        updateWheelPart(key, def.values[index]);
      }, 120);
    });
    column.addEventListener("click", e => {
      const item = e.target.closest(".wheel-item");
      if (item) updateWheelPart(key, Number(item.dataset.value));
    });
  });
}
function updateWheelPart(key, value) {
  if (!wheelState || wheelState[key] === value) return;
  wheelState[key] = value;
  if (activeWheelInput.type === "date" && wheelState.day > wheelDaysInMonth()) wheelState.day = wheelDaysInMonth();
  renderWheelColumns();
}
function openWheelPicker(input) {
  activeWheelInput = input;
  if (input.tagName === "SELECT") {
    wheelState = { optionIndex: Math.max(0, input.selectedIndex) };
    $("wheelTitle").textContent = input.id.indexOf("Cls") >= 0 || input.id === "cls" ? "Sinf tanlash" : "O‘quvchini tanlash";
  } else if (input.type === "date") {
    const parts = (input.value || today()).split("-").map(Number);
    wheelState = { year: parts[0], month: parts[1], day: parts[2] };
    $("wheelTitle").textContent = "Sana tanlash";
  } else {
    const parts = (input.value || nowStr()).split(":").map(Number);
    wheelState = { hour: parts[0], minute: parts[1] };
    $("wheelTitle").textContent = "Vaqt tanlash";
  }
  document.body.classList.add("wheel-modal-open");
  $("wheelBackdrop").hidden = false;
  renderWheelColumns();
  document.addEventListener("keydown", onWheelKeydown);
  $("wheelCancel").focus();
}
function applyWheelSelection() {
  if (!activeWheelInput) return;
  if (activeWheelInput.tagName === "SELECT") activeWheelInput.selectedIndex = wheelState.optionIndex;
  else activeWheelInput.value = activeWheelInput.type === "date" ?
    wheelState.year + "-" + pad(wheelState.month) + "-" + pad(wheelState.day) :
    pad(wheelState.hour) + ":" + pad(wheelState.minute);
  activeWheelInput.dispatchEvent(new Event("input", { bubbles: true }));
  activeWheelInput.dispatchEvent(new Event("change", { bubbles: true }));
  closeWheelPicker();
}
function initAndroidWheelPickers() {
  if (!/Android/i.test(navigator.userAgent)) return;
  document.body.classList.add("android-wheel-picker");
  ["fdate", "date", "earlyDate", "earlyListDate", "time", "earlyTime", "cls", "name", "earlyCls", "earlyName"].forEach(id => {
    const input = $(id), isDate = input.type === "date", isSelect = input.tagName === "SELECT";
    let wrapper = input.parentElement;
    const wrapperClass = isSelect ? "select-wrap" : isDate ? "date-wrap" : "time-wrap";
    if (!wrapper.classList.contains(wrapperClass)) {
      wrapper = document.createElement("div");
      wrapper.className = wrapperClass;
      input.parentNode.insertBefore(wrapper, input);
      wrapper.appendChild(input);
    }
    const trigger = document.createElement("button");
    trigger.type = "button";
    trigger.id = id + "WheelTrigger";
    trigger.className = "wheel-picker-trigger";
    trigger.setAttribute("aria-label", isSelect ?
      (id.indexOf("Cls") >= 0 || id === "cls" ? "Sinfni tanlash" : "O‘quvchini tanlash") :
      isDate ? "Sanani tanlash" : "Vaqtni tanlash");
    input.classList.add("wheel-picker-source");
    input.tabIndex = -1;
    input.insertAdjacentElement("afterend", trigger);
    const label = document.querySelector("label[for='" + id + "']");
    if (label) label.htmlFor = trigger.id;
    wheelInputs[id] = { input, trigger };
    refreshWheelDisplay(id);
    input.addEventListener("change", () => refreshWheelDisplay(id));
    trigger.addEventListener("click", () => openWheelPicker(input));
  });
  $("wheelCancel").onclick = closeWheelPicker;
  $("wheelApply").onclick = applyWheelSelection;
  $("wheelBackdrop").onclick = e => { if (e.target === $("wheelBackdrop")) closeWheelPicker(); };
}
function makeXlsx(rows, sheet) {
  if (typeof XLSX === "undefined") throw new Error("xlsx");
  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws["!cols"] = [{ wch: 5 }, { wch: 30 }, { wch: 8 }, { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 28 }, { wch: 20 }, { wch: 10 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheet);
  return XLSX.write(wb, { type: "array", bookType: "xlsx" });
}

async function downloadXlsx(filename, data) {
  const blob = new Blob([data], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  });

  const savePlugin = window.Capacitor?.Plugins?.AppUpdater;
  if (window.Capacitor?.isNativePlatform?.() && savePlugin?.saveFile) {
    const bytes = data instanceof ArrayBuffer
      ? new Uint8Array(data)
      : data instanceof Uint8Array
        ? data
        : new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    const chunkSize = 0x8000;
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + chunkSize));
    }
    await savePlugin.saveFile({
      fileName: filename,
      base64: btoa(binary)
    });
    return;
  }

  const ios = /iPhone|iPad|iPod/i.test(navigator.userAgent);
  if (ios && typeof navigator.share === "function" && typeof navigator.canShare === "function" && typeof File !== "undefined") {
    const file = new File([blob], filename, { type: blob.type });
    if (navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: filename
        });
        return;
      } catch (err) {
        if (err && err.name === "AbortError") throw err;
      }
    }
  }

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

const ROSTER = {"5-A":["ABDIXALILOV MUHAMMADZOHID ABDUJALIL O‘G‘LI","ABDULXAMIDOVA DURDONA AKMAL QIZI","ABDUSATTOROVA DILDORA ISMOILJON QIZI","AXMADJONOV ISLOMJON INOMJON O‘G‘LI","AXMADJONOVA MUSHTARIYBONU ADXAMJON QIZI","BAXODIROV ASADBEK XASANBOY O‘G‘LI","DO‘SBAYEV OG‘ABEK ORTIQBOY O‘G‘LI","DODOVA MUMTOZBEGIM MUXTORJON QIZI","G‘ANIJONOV FAZLIDDIN O‘KTAMJON O‘G‘LI","G‘AYBULLAYEV DONIYORJON ALIYOR O‘G‘LI","IBROXIMOV INOMJON ISOQJON O‘G‘LI","IKROMJANOVA KAMOLA ISRAILJON QIZI","IKROMOV ASILBEK AZIZJON O‘G‘LI","ISROILOV MUHAMMADQODIR RAXMON O‘G‘LI","MAMADJONOVA UMIDA SHERZOD QIZI","MUXAMADMUSOYEV IXTIYOR OTABEK O‘G‘LI","OLIMJANOVA MOHLAROY QAXRAMON QIZI","RAXIMJANOV MIRZOHID MUZAFFAR O‘G‘LI","RAXMATILLAYEV FURQATBEK FARXOD O‘G‘LI","SHAVKATOV NOZIMJON NOSIR O‘G‘LI","TOJIMAMATOV AHMADJON ABDULLAJON O‘G‘LI","UMARALIYEVA AFRUZA DILSHOD QIZI","VALIJONOV MUHAMMADRIZO JASURBEK O‘G‘LI","XABIBULLAYEVA FARANGIZ TOXIRJON QIZI","XABIBULLAYEVA GULZODA ZOKIR QIZI","XASANBAYEV NODIRBEK ULUG‘BEK O‘G‘LI","XOJIDEDAYEV BEHZODBEK BAXTIYOR O‘G‘LI","XOTAMJANOVA MOHINUR DONIYOR QIZI","XUSANBOYEV ABRORBEK ELMUROD O‘G‘LI","ZOKIRJONOV ISLOMJON RAVSHANBEK O‘G‘LI","ZOKIRJONOVA ZULFIYABONU ABDUMALIK QIZI"],"5-B":["ABDUJABBAROV MIRZIYO ABDULAZIZ O‘G‘LI","ABDURAIMOV HOJIAKBAR HUSANBOY O‘G‘LI","ABDUSALOMOVA DURDONA RUSTAM QIZI","ABDUVAXOBOV SHOHRUZBEK ULUG‘BEK O‘G‘LI","ABDUVOXIDOVA SHUKRONA ABDUBANNO QIZI","ALISHEROV AHADJON AZIZBEK O‘G‘LI","BAXROMJONOVA MARJONA MIRZOXID QIZI","G‘AFURJONOVA DILFUZA DILSHOD QIZI","IBROXIMJONOVA SARVINOZ SANJARBEK QIZI","ILXOMJANOV HUMOYUN SANJARBEK O‘G‘LI","INAMOVA SAMIRA FARXOD QIZI","ISMONJONOV IXTIYORBEK BAXTIYOR O‘G‘LI","MAXMUDJONOVA SARVINOZ MA‘MURJON QIZI","RAXIMJONOVA FOTIMAXON ADXAMJON QIZI","RAXIMJONOVA ZUHRAXON ADXAMJON QIZI","RUSTAMOVA GULYORA O‘KTAM QIZI","SADRIDDINOVA DURDONA SARDORBEK QIZI","SHUXRATOV SHOHRUHBEK SHOKIR O‘G‘LI","SOBITXONOVA MOHLAROYIM ABRORJON QIZI","TOXIRJONOVA MUSLIMA ALISHER QIZI","TURABOYEV SARDOR BOBUR O‘G‘LI","VOHIDJONOV SAIDBEK DILSHOD O‘G‘LI","XAMIDBOYEV UMIDBEK MA‘RUFJONOVICH","XAMITBAYEVA MUBINAXON UMIDJON QIZI","XAMITBOYEV MUHAMMADZIYO ILXOMJON O‘G‘LI","XOJIAKBAROVA MUBINA MAXSUD QIZI"],"5-D":["ABDIBANNAYEV YUNUSXON ABDURASHID O‘G‘LI","ABDIXAMIDOV MURODJON DILSHOD O‘G‘LI","ABDUNABIYEV OYBEK AVAZBEK O‘G‘LI","ABDUVOXIDOV ASADBEK FAXRIDDIN O‘G‘LI","ABITXONOV SHOHRUHBEK SARDOR O‘G‘LI","AXATJONOVA HAYRINISO ODILJON QIZI","AXMADJANOV BARKAMOL AKMALJON O‘G‘LI","AXMADJONOV ABDULAZIZ G‘ULOMJON O‘G‘LI","AXMADJONOVA O‘G‘ILOY MURODILLA QIZI","AXMADJONOVA SHIRIN A‘ZAMJON QIZI","EGAMBERDIYEV MUHAMMADZIYO MUSLIMJON O‘G‘LI","G‘ANISHEROV SHERMUHAMMAD AZAMAT O‘G‘LI","IKRAMOVA MARJONA ISMOIL QIZI","IKROMJONOVA SHODIYA NURMUXAMMAD QIZI","IKROMOV ISLOMJON ISROILJON O‘G‘LI","ISMONJANOV FIRDAVS FARHOD O‘G‘LI","IZZATILLAYEVA GULASAL MUZAFFAR QIZI","JO‘RAYEV ISLOMBEK IBROHIMJON O‘G‘LI","MUXAMMADISMOILOV MUHAMMADALI O‘TKIRJON O‘G‘LI","NOSIRJONOV DOVUDXON IKROM O‘G‘LI","NOSIRJONOV YOQUBJON SODIQJON O‘G‘LI","OLIMJONOVA JASMINA JASURBEK QIZI","ORTIQBAYEVA GULSHODA ALIMARDON QIZI","RAXIMJONOVA MUHTARAMXON XASANBOY QIZI","TURSUNBOYEV AKBARJON AKMAL O‘G‘LI","UMARALIYEVA MUSHTARIY ABDULATIF QIZI","USMONALIYEVA GULZODAXON ISMOIL QIZI","VOXIDJANOVA MUSLIMABONU BEGZOD QIZI","XASANBOYEV ASRORBEK ADHAMJON O‘G‘LI","XASANBOYEVA NOZIMAXON DILMUROD QIZI","ZOKIRJONOVA SHUKRONA QOBUL QIZI"],"5-E":["ABDUG‘ANIYEV MUHAMMADYUSUF ABDURASUL O‘G‘LI","ABDUMUMINOV ULUG‘BEK ABROR O‘G‘LI","ABDUMUTALOV SARDOR SHERALI O‘G‘LI","ABDUXALILOVA ZULFIRA AKRAMJON QIZI","AKBARXUJAYEVA MUSLIMAXON ABROR QIZI","AVAZXONOVA OQILA ISLOM QIZI","BAXTIYOROVA MUSHARRAF ISKANDAR QIZI","BOYMURADOV ABDULLOH ABDUGAFFOR O‘G‘LI","ISMONJANOV SARDORBEK RUSTAMJON O‘G‘LI","JURABOYEV BAXTIYOR ABDULXOMID O‘G‘LI","KOMILJONOVA SHAHRIZODA ODIL QIZI","MAMADJONOV DILMUROD DILSHOD O‘G‘LI","MAMADJONOVA MUHLISA QOBULJON QIZI","MANSUROVA GULASAL OYBEK QIZI","MAXMUDJONOVA SARVINOZ OLIMJON QIZI","O‘RAZMATOVA AZIZAXON AZAMAT QIZI","O‘ROLOVA MUMTOZBEGIM AZAMATOVNA","RAVSHANBEKOVA SHIRINOY DOSTON QIZI","RAXMATILLAYEVA MUSHTARIYBONU ABDULXAMID QIZI","RAXMATILLAYEVA SHAHODAT SHAVKATJON QIZI","RAXMONBERDIYEV ABUBAKR ABRORJON O‘G‘LI","RUSTAMJONOV DIYORBEK BAXROMJON O‘G‘LI","TURSUNBOYEV MUHAMMADZIKIRYO BAXROMJON O‘G‘LI","TURSUNBOYEV RASULBEK RAVSHANBEK O‘G‘LI","TURSUNBOYEVA MOHINUR BEKZOD QIZI","VALIJONOVA MEHRIBONU OTABEK QIZI","XAMITBOYEV FAYOZBEK USMIRJON O‘G‘LI","YOQUBJONOVA MUSHTARIY TOXIRJON QIZI"],"5-F":["ABDULXAMIDOV AZAMAT MIRZOXID O‘G‘LI","ABDUNABIYEV AZIZBEK MIRZOXID O‘G‘LI","ATAXANOVA YASMINA ILXOMJON QIZI","BAXROMJANOVA FARANGIZ SALIMJON QIZI","DILSHODOV ASADBEK DONIYOR O‘G‘LI","ERGASHBOYEV IBROHIM ASHURALIYEVICH","ERKINBOYEV AKBARJON ILXOM O‘G‘LI","IKROMJONOV ADHAMJON AKBAR O‘G‘LI","JURAXONOVA GULASALXON ILXOMJON QIZI","KIMSANJONOV FIRDAVS FARRUX O‘G‘LI","MAMADALIYEV HUMOYUNBEK AKMALJON O‘G‘LI","MAXMUDJONOVA KUMUSHOY MANSUR QIZI","ODILJONOV JAHONGIR ANVAR O‘G‘LI","OLIMJANOV AZIZBEK ANORBEK O‘G‘LI","OLIMJANOVA MUAZZAMXON LUXMONJON QIZI","OLIMJONOV SARDORBEK JAFARBEK O‘G‘LI","ORIBJONOV MUHAMMADALI MUROD O‘G‘LI","RAVSHANJONOV NURMUHAMMAD JAVLON O‘G‘LI","RO‘ZIMATOVA GULOYIM XASANBOY QIZI","SHOKIROV AZAMAT BEKZODJONOVICH","SOBIROVA SARVINOZ XUSNIDIN QIZI","TAVAKKALOV MURODJON QODIRJON O‘G‘LI","TURG‘UNBOYEVA ZIYODAXON OYBEK QIZI","TURG‘UNPULATOV AKBARALI MA‘RUFJON O‘G‘LI","UBAYDULLAYEVA HUSHNOZABEGIM JAXONGIR QIZI","ULMASBOYEV AKRAMJON BAXROMJON O‘G‘LI","XAMITXONOVA HADICHABEGIM ISMOILJON QIZI"],"6-A":["ABDIRAXIMOVA FOTIMAXON ABDURASHID QIZI","ABDIRAXIMOVA ZUHRAXON ABDURASHID QIZI","ABDUG‘ANIYEVA MUBINAXON ABDUJABBOR QIZI","ABDUG‘OPPOROVA TURSUNOY ABDUMAJID QIZI","ABDUMAJITOV AHRORBEK ANVARJON O‘G‘LI","ABDUMAJITOV JAHONGIR ABDUMUTAL O‘G‘LI","ABDUPATTOYEVA MEHRINISO MA‘MURJON QIZI","ABDUVOXIDOVA KUMUSH XUSANBOY QIZI","AHMADJONOV AVAZBEK A‘ZAMJON O‘G‘LI","AKRAMJONOVA ZEBO G‘ULOM QIZI","AXMADJONOV NURIDDINBOY AKMALJON O‘G‘LI","AXMADOVA FARANGIZOY ANVARJON QIZI","BEKMIRZAYEV MAQSADJON ELMURODOVICH","DAVLATALIYEV IBROHIM MASHRABBOY O‘G‘LI","G‘ANIJONOV YIGITALI RUSTAM O‘G‘LI","IBROXIMOVA MUBINA ISMOILJON QIZI","JO‘RABOYEVA ZARINA UZEN QIZI","JO‘RAMIRZAYEV OTABEK G‘ULOMJONOVICH","LUTFULLAYEVA AZIZAXON TOXIRJON QIZI","LUTFULLAYEVA DURDONA BOTIRJON QIZI","ODILJONOV ABRORBEK QOBULJON O‘G‘LI","ODILJONOVA DILSHODA SOXIBJON QIZI","OLIMJONOV SOBITJON ORIFJON O‘G‘LI","RAXMATILLAYEVA MARJONA SHERZOD QIZI","RAZIKOV BAHODIR BAXROMOVICH","RAZIKOV BAHODIR BAXROMOVICH","RUSTAMJONOV JAMSHIDBEK OTABEK O‘G‘LI","TAXIRJANOV ULUG‘BEK UMIDJON O‘G‘LI","TOJIMIRZAYEV HUSNIDDIN XUSANBOY O‘G‘LI","YO‘LDOSHBOYEV AZIZBEK RO‘ZIMAMAT O‘G‘LI","YULDASHEVA DILDORA QAHRAMON QIZI","ZOKIRJANOV ABDUMAJID ABDUXALIL O‘G‘LI"],"6-B":["ABDILXAMIDOVA SHOHIDAXON MUZAFFAR QIZI","ABDULQODIROV FIRDAVS QOBILJON O‘G‘LI","ABDUMALIKOVA DILNOZA ALISHER QIZI","ABDURASULOVA CHAROSXON ABDULLAJON QIZI","ABDURAXIMOV AQLBEK ABROR O‘G‘LI","ABDUXALILOVA ZEBINISO ALIJON QIZI","ADASHALIYEV JAHONGIR UMIDJON O‘G‘LI","ADASHALIYEV ZOHIDBEK MUXAMMADZOKIR O‘G‘LI","ALIMJANOV BEHRUZBEK AZIMJON O‘GLI","BAXTIYOROV UMIDJON DONIYORBEK O‘G‘LI","BOTIRJONOVA DURDONA ANVAR QIZI","BOZORBOYEVA MUBINAXON BAXTIYOR QIZI","G‘OFUROVA ZULFIYA AZIZBEK QIZI","IKROMJONOVA FARANGIZ FAXRIDDIN QIZI","KOMILJONOVA GULSANAM OBID QIZI","MAMADURAYIMOVA MOHLAROYIM KOMILJONOVNA","MAXAMMADINOV JAHONGIR MURODJON O‘G‘LI","MAXAMMADJONOV QOBILJON ABDULQODIR O‘G‘LI","MAXMADJONOV XUDOYORXON AKBAR O‘G‘LI","MAXMUDJONOV JAVHARALI RUSTAMBEK O‘G‘LI","NE‘MATJONOVA MUSLIMA QOSIMJON QIZI","NISHONBOYEV JASURBEK ADHAMJON O‘G‘LI","NOMONJONOVA SHABNAM A‘ZAMJON QIZI","NOSIRJONOVA MADINABONU NOZIMBEK QIZI","QODIRJANOVA MUSLIMA ANVARJON QIZI","RAVSHANBEKOVA ZIYODA OTABEK QIZI","TOXIRJONOV HUSANBOY OYBEK O‘G‘LI","TOXIRJONOVA FOTIMAXON OYBEK QIZI","XABIBULLAYEVA MUBINABONU BAXTIYOR QIZI","XOLIQOVA SEVINCH ABDURASHID QIZI","YUSUPOV ZIYODULLOH XABIBULLO O‘G‘LI","YUSUPOVA MARJONA XUSANBOY QIZI"],"6-D":["ABDIG‘APPOROVA GULHIDA FARRUX QIZI","ABDIXALILOV ASADBEK BAXTIYOR O‘G‘LI","ABDUQAXXOROV ALISHER ZOKIRJON O‘G‘LI","ABDUVALIYEV AZIZBEK DILMUROD O‘G‘LI","ABDUVAXIDOVA NODIRABEGIM ABDUNOZIR QIZI","ABDUVOHIDJONOV ALI ABDUXALIL O‘G‘LI","ABDUXALILOVA GO‘ZALXON XAMIDDILLO QIZI","AHMADJONOVA SHAHNOZA UMIDJON QIZI","ALISHEROV MUHAMMADRIZO RAVSHAN O‘G‘LI","ALISHEROV SHAMSHODBEK SHUXRAT O‘G‘LI","ANVARJONOV XURSHIDBEK ABROR O‘G‘LI","AXMADJONOVA AZIZABONU AKMALJON QIZI","BAXROMJONOVA ASALXON ILXOM QIZI","BOYXONBOYEVA OZODAXON JAXONGIR QIZI","DILSHODOV DILYORBEK DILMUROD O‘G‘LI","G‘AYBULLAYEV AZIZBEK A‘ZAMJON O‘G‘LI","IKROMJONOVA MAHLIYO AKRAMJON QIZI","ISMONJONOVA GULIRA‘NO ILXOMJON QIZI","MURODILLAYEV JASURBEK ALIJON O‘G‘LI","NABIJONOVA SARVINOZ G‘ULOM QIZI","OLIMJANOVA DILSO‘Z ANVAR QIZI","OLIMJONOVA MADINABONU UMID QIZI","ORIBJANOVA MUSLIMA OLIMJON QIZI","ORIFOVA MEHRIBONU RAVSHANBEK QIZI","RAXIMOV SAIDAKBAR RAFIQ O‘G‘LI","SHOKIRJONOV RAHMATILLO SHAVKATJON O‘G‘LI","SOBIRJONOVA SARVINOZ SODIQJON QIZI","SOLIJANOV ISLOMJON G‘ULOM O‘G‘LI","TURG‘UNBOYEV MUHAMMADIBROHIM ALISHER O‘G‘LI","UROYIMJANOVA ISMINOZ ILYOSOVNA","XOLMUXAMMADOV ABRORBEK SHERZOD O‘G‘LI","ZAKIRJONOVA SHODIYA ELYOR QIZI"],"6-E":["ABDIBANNAYEVA SHAHINABONU ABDUNOSIR QIZI","ABDILAJONOVA SHODIYA AKRAMJON QIZI","ABDIMAMATOVA MARJONAXON BAXTIYOR QIZI","ABDURASHIDOVA GULYUZ AKMALOVNA","ABDURASULOV ASRORBEK AKMALJON O‘G‘LI","ABDUSATTAROVA GULASAL FARXOD QIZI","AYDAROVA OYSHAXON XXX","BAXROMOVA MUBINABONU BAXROM QIZI","BEKZODOVA JASMINA BEKZOD QIZI","BOQIJANOVA CHAROSXON BAXROMJON QIZI","BOTIRJONOV ABDUSAMAD FAXRIDDIN O‘G‘LI","ERGASHEVA MARXABOXON RAXIM QIZI","G‘ULOMJANOVA SHODIYABONU MUQINJON QIZI","ISOQJONOV MIRZOHID ALISHER O‘G‘LI","ISOQJONOVA MUNZIRA IBROHIM QIZI","ISOQJONOVA SHODIYA DILSHOD QIZI","KARIMOV OYATILLO AXMADJON O‘G‘LI","NAJMIDDINOV FARRUX SADRIDDIN O‘G‘LI","NURIDDINOV MUHAMMADYUSUF RUSTAM O‘G‘LI","ODILJONOV HUMOYUNBEK XAYTBOY O‘G‘LI","OLIMJANOV BILOL ORIFJON O‘G‘LI","ORTIQBOYEV AZIZBEK NODIRBEK O‘G‘LI","QODIRJONOVA NOZIMA MUROD QIZI","TESHABAYEV YUSUPALI SULTANBAYEVICH","TURABOYEV HURSHIDBEK MA‘MUROVICH","XABIBULLAYEV JASURBEK MIRZOXID O‘G‘LI","XAKIMOV ZOIRSHOH SHERZOD O‘G‘LI","XOLMIRZAYEVA MARJONA MUZAFFAR QIZI","XUSANBOYEVA MOHIDIL DILMUROD QIZI"],"6-F":["ABDUMALIKOVA MADINA ABDURAXIM QIZI","ABDUQAXXOROVA MUMTOZABEGIM A‘ZAMAT QIZI","ABDURASULOV IBROHIMJON ABDULBOQI O‘G‘LI","ABDUSATTOROVA MAFTUNA OLIMJON QIZI","ABDUVALIYEVA MAXSUMAXON AXMADJON QIZI","AHMADJONOVA ZINNATXON AVAZBEK QIZI","AKBAROVA GAVHAROY ABDULAZIZ QIZI","AKRAMJONOVA MADINABONU RUSTAMJON QIZI","ALISHEROVA SHAHRIBONU XUSNIDDIN QIZI","AXMADJANOVA DURDONA ADXAMJON QIZI","AXMATJONOV DIYORBEK DONIYOR O‘G‘LI","IKROMJANOVA DILNOZA BAXROMJON QIZI","ILXOMJONOV JAMSHID ALISHER O‘G‘LI","ISMATULLAYEV MUSTAFO IZZATULLA O‘G‘LI","ISOQJANOVA MARJONA BAXTIYOR QIZI","KOMILJANOVA FERUZA SHAVKAT QIZI","KOMILJANOVA GULISHODA DILMUROD QIZI","KOMILJONOV HUMOYUNMIRZO SHOKIR O‘G‘LI","KOMILJONOV INOMJON ISLOMJON O‘G‘LI","MAMADJONOVA MASTONA SHAVKATJON QIZI","MURODILLAYEV SHODIYORBEK SHERZOD O‘G‘LI","ODILJANOVA SHODIYAXON UTKIR QIZI","QO‘CHQORBOYEV MIRZIYO ABDUG‘OFIR O‘G‘LI","QO‘CHQOROV SANJARBEK DONIYOR O‘G‘LI","RAXMATILLAYEVA AZIZA AXMADJON QIZI","RO‘ZIMAMATOV ASILBEK ORIFJON O‘G‘LI","RUSTAMJANOVA MO‘TABARXON ABDURASHID QIZI","SAIDIKRAMOVA MUXARRAM RAXMATILLA QIZI","SOBIRJANOV XURSHIDBEK ZOKIRJON O‘G‘LI"],"7-A":["ABDINABIYEVA ASALXON MUZAFFAR QIZI","ABDIQODIROVA NAFISA ILXOMJON QIZI","ABDUG‘ANIYEVA BEGOYIM UMIDJON QIZI","ABDUG‘APPOROVA FARANGIZBONU BOTIR QIZI","ABDULXAMIDOVA SHAXNOZABONU ANVARJON QIZI","AXMADJANOVA GULSORA BUNYODJON QIZI","AZIMBOYEV AVAZBEK ABROR O‘G‘LI","BOZORBAYEVA DILDORA BOTIRJON QIZI","G‘ULOMJANOVA GULASAL ALISHER QIZI","G‘ULOMJONOVA NAFISAXON TOLIBJON QIZI","INOMJONOV FIRDAVS JAMSHID O‘G‘LI","IZZATILLAYEV ILG‘ORBEK ILYOS O‘G‘LI","JALILOV AXMADILLO ABDUXALIL O‘G‘LI","KAMOLIDDINOVA AZIZAXON SIROJIDDIN QIZI","KAMOLXONOV XURSHIDBEK OTABEKOVICH","KOMILJANOV SHUKRULLO SHERZOD O‘G‘LI","MAHAMMADJONOV MURODJON G‘ULOM O‘G‘LI","MAVLANOVA SARVINOZ AXADJON QIZI","MAXMUDJONOV MUHAMMAD DILSHOD O‘G‘LI","MIRZAXMEDOV SHERDORBEK MUZAFFAR O‘G‘LI","MURODILLAYEV DIYORBEK DILSHODBEK O‘G‘LI","MUXAMADJONOVA GULASAL RUSTAMJON QIZI","OLIMJONOVA NASTARIN JASURBEK QIZI","RO‘ZIBAYEVA DURDONA BUNYOD QIZI","RUSTAMOVA GULASAL UKTAM QIZI","SHERMIRZAYEV SHAHZODBEK SHERZOD O‘G‘LI","TOXIRJONOVA MARJONA ALISHER QIZI","TURG‘UNBOYEVA LOLAXON RAXIMJON QIZI","UMARJONOV SAIDBEK ZAYNIDDIN O‘G‘LI","VALIJONOVA MOHINUR JASURBEK QIZI","VALISHEROV AHRORBEK SARDOR O‘G‘LI","XOJIAKBAROVA MUSLIMA MAXSUD QIZI"],"7-B":["ABDINABIYEVA SARVINOZ JAMOLIDDIN QIZI","ABDULLAJANOVA SHABNAM SHUXRAT QIZI","AKROMJONOVA MUBINA BEKZOD QIZI","ALISHEROV AKOBIR ANVARJON O‘G‘LI","ANVARJONOV HOJIAKBAR AKRAM O‘G‘LI","AVAZBEKOV MAQSUDBEK SHUXRATJON O‘G‘LI","BAXODIROVA SHUKRONA ISROIL QIZI","BAXROMOV HUMOYUN AKMALJON O‘G‘LI","BOTIROVA MOHINUR XASANBOY QIZI","ERGASHBOYEV BEKZODBEK BOTIRJON O‘G‘LI","ERGASHBOYEVA E‘ZOZA VALIJON QIZI","ERKINBOYEVA AZIZAXON ILXOM QIZI","GAPPAROV FYODOR MUSHRIF VOSILOVICH","IMOMALIYEVA ZULAYHO XUDAYBERDI QIZI","ISOQJONOV MUHAMMADALI RUSTAMJON O‘G‘LI","JALILOV MUSTAFO BAXTIYOR O‘G‘LI","KIMSANJONOVA CHAROSXON FARRUX QIZI","MAMADJANOVA DILRABO ELMUROD QIZI","MAMAJONOV BAHODIR RUSTAM O‘G‘LI","MURODILLAYEVA JASMINA ELYORJON QIZI","NEMATJONOV OZODBEK AKMALJON O‘G‘LI","QOSIMBOYEVA BEGOYIM BAHODIR QIZI","SIDIQJONOV AZIZBEK ELYOR O‘G‘LI","SOLIJANOV BEHRUZBEK XAITMIRZA O‘G‘LI","SOLIJONOVA OYGUL AZIMJON QIZI","TURG‘UNBOYEVA XONZODA OCHILBEK QIZI","TURG‘UNPULATOVA DURDONA QODIRJON QIZI","TURSUNBEKOVA SALIMAXON OTABEK QIZI","XAYRULLAYEVA FERUZA XABIBULLO QIZI","XOSHIMBOYEV DIYORBEK XAKIMZODA O‘G‘LI","YODGOROV ABDUMALIK ABDUMUTAL O‘G‘LI","ERGASHEV AXRORBEK AXMADJON O‘G‘LI"],"7-D":["ABDUG‘ANIYEV A‘ZAMJON MUZAFFAR O‘G‘LI","ABDUMALIKOVA BARCHINOY QUDRATJON QIZI","ABDUVOXIDOVA HUSHNOZABEGIM ABDULAZIZ QIZI","ALIJONOVA DILNOZA ALIJON QIZI","ALISHEROV ABDULLOH ODILJON O‘G‘LI","ARTIQBAYEVA ZILOLAXON ELYOR QIZI","ATABAYEVA MARJONA UMIDILLO QIZI","AXMADOV NURBEKJON NE‘MATJON O‘G‘LI","BAXODIROV JASURBEK ABDURASHID O‘G‘LI","BOTIRJONOVA MUBINAXON BAXRIDDIN QIZI","DOLIMJONOVA DIYORA NODIRBEK QIZI","ERGASHBAYEV SANJARBEK OLIMJON O‘G‘LI","IBRAXIMOVA NIGORAXON G‘ULOMJON QIZI","ISKANDAROVA DURDONA MAXAMMADALI QIZI","ISLOMJONOV JAHONGIR UBAYDILLA O‘G‘LI","JURAXONOVA DIYORAXON ULUG‘BEK QIZI","KAZAKJANOV AZIZBEK KOMILJON O‘G‘LI","KOMILJANOV IKROMJON ILHOMJON O‘G‘LI","KOMILJANOVA DURDONA DONIYOR QIZI","KOMILJONOV SHOXJAXON BEKZOD O‘G‘LI","MAXAMATJONOVA MADINABONU RUSTAMJON QIZI","MAXAMMADJANOVA MADINA ABDUMALIK QIZI","MURODILLAYEV BEHRUZBEK ANVARJON O‘G‘LI","ODILJONOV AFZALBEK O‘KTAM O‘G‘LI","TURSUNBOYEVA DURDONAXON AKMALJON QIZI","XAKIMOV SHAHBOZ SHERZOD O‘G‘LI","AXMADJONOVA SEVINCH UMARJON QIZI","JUMANALIYEV AZIZBEK YULDUZBEK O‘G‘LI","IBROXIMOV JOBIRBEK MA‘RUF O‘G‘LI","FOZILJONOV JASURBEK RUSTAM O‘G‘LI","ERKINOV RAXMATILLO BAXTIYOR O‘G‘LI"],"8-A":["ABDUKARIMOVA NOZIMA MAVLONBOY QIZI","RAXMATILLAYEVA DILAFRO‘Z AXAMADJON QIZI","RUSTAMOVA RUXSORA BATIR QIZI","ABDUBANNOYEV BAXRIDDIN ABDUBAXROM O‘G‘LI","ABDULLAYEV AZIZBEK SHUXRAT O‘G‘LI","ABDULLAJONOVA RAYXONA ABDUXAJON QIZI","ABDURASULOV O‘KTAMJON ABDULAZIZ O‘G‘LI","AVAZBEKOV ASILBEK JASUR O‘G‘LI","AKRAMJONOVA VASILAXON ADXAMJON QIZI","ATAXANOVA BIBISORA ILXOMJON QIZI","G‘OFUROVA JAMILA JAMOLIDDIN QIZI","YOQUBJONOV DAVLATBEK YORQIN O‘G‘LI","JOXONALIYEV ILXOMJON DILMUROD O‘G‘LI","JO‘RABOYEVA SEVARA ABDULXAMID QIZI","IKROMJONOV AKMALJON AKBAR O‘G‘LI","IMINOVA ZUXRA MUZAFFAR QIZI","IMINOVA FOTIMA MUZAFFAR QIZI","MALLABOYEVA MANZURAXON MURODJON QIZI","MAXAMMADOVA MARJONA MIRZAJON QIZI","MAXAMMATJONOV AXLIDDIN FARXODJON O‘G‘LI","NISHONBOYEV AZIZBEK AKRAMJON O‘G‘LI","OLIMJANOVA SHAXLOXON ORIFJON QIZI","OTAXONOVA MUSHTARIY SHOKIRJON QIZI","RAIMJONOVA ZARINA XASANBOY QIZI","RAXMATOVA OYDINA BAHODIR QIZI","TOXIRJONOV ADXAMJON RAXIMJON O‘G‘LI","TURG‘UNOV DOVUDXON RAXIMJON O‘G‘LI","XABIBULLAYEV FIRDAVS TOXIRJON O‘G‘LI","ERGASHEV A‘ZAMJON TO‘XTABOY O‘G‘LI"],"8-B":["LUTFILLAYEVA GULXIDA ABDULXAKIM QIZI","MAMADJONOV SHOHRUHBEK SHAVKATJON O‘G‘LI","TURSUNPULATOV AKRAMJON FARHOD O‘G‘LI","ABDUVALIYEVA MUBINA AKMALJON QIZI","ABDULXAMIDOV JALOLIDDIN ILXOMJON O‘G‘LI","ABDUMAJITOVA DURDONA ABDUMUTAL QIZI","ABDUNABIYEVA JASMINA UMIDJON QIZI","AXMADJONOV ASILBEK A‘ZAMJON O‘G‘LI","AXMADJONOV AFZALBEK AKMALJON O‘G‘LI","AXMADJONOVA MADINABONU DILMUROD QIZI","AXMADJONOVA MOHLAROY MURODILLA QIZI","AXMADOVA FAZILATOY ANVARJON QIZI","AHMADJONOV DAVLATSHER BAXROMJON O‘G‘LI","BAXODIROVA MOXIRA BAXTIYOR QIZI","DOLIMJANOVA GULZODA ABDUNABI QIZI","ZOKIRJONOVA SHABNAM ELYOR QIZI","IKROMJONOV SANJARBEK XAMIDULLO O‘G‘LI","KAMOLXONOVA KAMOLA OTABEKOVNA","LUTFULLAYEV MUHAMMADSODIQ BAXRIDDIN O‘G‘LI","MAXAMADALIYEV AVAZBEK ADXAMJON O‘G‘LI","MIRZAMAXMUDOV JAXONGIR BOTIRJON O‘G‘LI","NABIYEVA MARJONA MUZAFFAR QIZI","ORIBJANOV AZIZBEK OLIMJON O‘G‘LI","RAXIMJONOVA MUSHTARIYBONU AKRAM QIZI","RAXIMJONOVA SHABNAM SARDORBEK QIZI","TURG‘UNBOYEVA RAYXONA OYBEK QIZI","XAMIDBOYEVA MARHABOXON BAXRIDDIN QIZI","XAMIDJONOV AZIZBEK MAXAMMADJON O‘G‘LI","XOLIQOV AKMALJON ABDUXALIL O‘G‘LI"],"8-D":["ABDIRAXIMOV ASADBEK ULUG‘BEK O‘G‘LI","ABDUMALIKOV SAIDBEK SIROJIDDIN O‘G‘LI","BAXRAMOV OZODBEK AVAZBEK O‘G‘LI","ISLOMJONOVA CHAROS ISLOMJON QIZI","MAXMADJONOVA MUMTOZABEGIM HABIBULLO QIZI","ABDUVOXIDOVA SHIRIN ABDUNOZIR QIZI","ABDURAXIMOV QILICHBEK O‘TKIRBEK O‘G‘LI","ABDURASHIDOVA MUSHTARIYBONU ABDURAXMON QIZI","AXMADJONOV SHAMSHODBEK DONIYOR O‘G‘LI","BOTIRJANOVA MADINABONU SHOKIRJON QIZI","DAVRONJONOV JAVOXIR JAVLON O‘G‘LI","DADABAYEVA GULBAXOR DILSHOD QIZI","IKROMJANOVA DILRABO BAXROMJON QIZI","KOMILJANOV AZIZBEK SHAVKAT O‘G‘LI","MAXAMATJONOVA RAYXONA ANVARJON QIZI","MAXAMMADJONOVA MADINA ABDULQODIR QIZI","NABIJONOVA MASHXURAXON ALIJON QIZI","NURIDDINOVA ASALXON RUSTAM QIZI","NURIDDINOVA MAFTUNA BAXTIYOR QIZI","RAXMATILLAYEVA DILNOZA SHAVKATJON QIZI","TURG‘UNOV SHOXJAXON ALISHER O‘G‘LI","TURSUNBOYEVA OYSHABIBI DILMUROD QIZI","USMONJONOVA MARXABO BAXRIDDIN QIZI","XAMIDJANOV NOZIMJON NE‘MAT O‘G‘LI","XOSHIMJONOV DIYORBEK ELYORJON O‘G‘LI","SHAMSHIDDINOVA RUXSHONA AZIZJON QIZI","SHERMATOV ABDULAZIZ AKRAMJON O‘G‘LI"],"8-E":["IKROMJANOVA SHOHSANAM ISROILJON QIZI","KOMILJANOVA MEHRIBONU DILMUROD QIZI","KOMILOV SOHIBBEK SOBIRJON O‘G‘LI","SHERMIRZAYEV BEHRUZBEK BEXZOD O‘G‘LI","ABDUVOXOBOV MUSTAFOBEK SHUXRATJON O‘G‘LI","ABDUQODIROVA MUBINA QOBILJON QIZI","ABDULXAMIDOV OTABEK AKMAL O‘G‘LI","ABDUSATTAROV JAXONGIR ISMOILJON O‘G‘LI","AKBARXO‘JAYEV YUSUFXON ABROR O‘G‘LI","ALISHEROV BEXRUZBEK BAXTIYOROVICH","ATABAYEVA MOXLAROYIM UMIDILLO QIZI","AXMADJONOV FARRUXBEK AKMALJON O‘G‘LI","AXMADJONOVA NOZIMA G‘ULOMJON QIZI","BOYMIRZAYEV BAXODIR BAXTIYOR O‘G‘LI","IKROMJONOVA MARXABO BAXROMJON QIZI","KAMOLOVA SABINA SOBIRJON QIZI","KOMILJONOVA ASALXON ODIL QIZI","QODIRJANOV BOBURJON BAXODIR O‘G‘LI","MAMADURAYIMOV ABBOSBEK KOMILJON O‘G‘LI","MAXAMADIBROXIMOV UMIDJON ABDURASUL O‘G‘LI","MAXAMADOV SARDORBEK SODIQJON O‘G‘LI","ORTIQBOYEVA MUSHARRAF ALISHER QIZI","RUSTAMJONOV ASADBEK DOSTONJON O‘G‘LI","TOKTOMAMBETOV DIYORBEK ELMUROD O‘G‘LI","UMARJONOV XAYOTBEK NODIRJON O‘G‘LI","UMAROV XAMIDULLO XAYRULLO O‘G‘LI","XOJIMAMATOVA MAVLUDAXON NURITDIN QIZI","SHARIPXOJAYEV ABBOS ILXOMJON O‘G‘LI","EGAMBERDIYEV MUHAMMADYUSUF MUSLIMJON O‘G‘LI","ERKINBOYEV ODILBEK OYBEK O‘G‘LI","YULDASHALIYEVA RUXSHONA DILMUROD QIZI","YAXYOMIRZAYEVNA SHAXRIZO SHOXRUX QIZI"],"8-F":["AXMADJONOVA DILOBAR A‘ZAMJON QIZI","ABDUKARIMOV SAMANDAR ABDUG‘AFFOR O‘G‘LI","ABDUSATTAROV ZOIRBEK ZAFARJON O‘G‘LI","ALIJANOV KAMRONBEK ELYOR O‘G‘LI","AXMADOVA GUZALOY A‘ZAMJON QIZI","G‘AFURJANOV SHUXRAT DILSHOD O‘G‘LI","G‘ULOMJONOVA RAYHONA ULUG‘BEK QIZI","DILSHODOV DIYORBEK DONIYOR O‘G‘LI","JAXONALIYEVA AZIZAXON ELMUROD QIZI","IBRAGIMOV SARDORBEK SOXIBJON O‘G‘LI","ILXOMJANOVA OYGUL SARDOROVNA","ILXOMJONOV ISFANDIYOR DONIYOROVICH","INOMADINOVA XALIMAXON IKROMJON QIZI","ISOQJANOV XURSHIDBEK OYBEK O‘G‘LI","KOMILJONOVA MADINABONU ISMOILJON QIZI","QUCHQAROVA MUBINABONU XASANBOY QIZI","QUCHQORBOYEV TEMURBEK ABDUMAJIT O‘G‘LI","MAMADALIYEVA DIYORAXON DILMURODOVNA","MAMADSHOYEVA ZARNIGOR MAMAJON QIZI","MAMURJANOVA MUNISA SHUXRATJON QIZI","OLIMJONOV BEXRUZBEK OLIMJON O‘G‘LI","RAXIMJONOV MUHAMMADALI ADXAMJON O‘G‘LI","RAXMATILLAYEVA KUMUSHBIBI ABDULXAMID QIZI","RUSTAMOV AKBAR ALISHEROVICH","TOJOXUNOV MUXAMMADRIZO MUXAMMADYUSUF O‘G‘LI","USUBBEKOV AZIZBEK ISLOMJON O‘G‘LI","SHERMIRZAYEVA MUAZZAM DILSHOD QIZI","ERGASHBOYEV JASURBEK DOLIMJON O‘G‘LI"],"9-A":["ABDUKARIMOVA MARJONA VALISHER QIZI","ABDURASULOV SHODIYORBEK ADXAMJON O‘G‘LI","ABDUXALILOVA YODGORA AZAMAT QIZI","ABSATTOROV SARVARBEK SAYDULLO O‘G‘LI","ALISHEROVA MARJONAXON ANVARJON QIZI","BAZARBAYEVA INTIZORBONU RAVSHANJON QIZI","BOQIJONOVA DIYORA OBIDJO N QIZI","VALIJANOVA MADINA OYBEK QIZI","ZOKIRJANOVA DURDONA FARXODJON QIZI","IKROMJONOVA RAYXONA ILXOMJON QIZI","QODIRJANOVA MUBINABONU ANVARJON QIZI","MAMADJANOVA MARXABO QOBULJON QIZI","MUMUNOV SHAXRIYOR RAVSHANBEK O‘G‘LI","ODILJONOVA ZILOLA XAYTBOY QIZI","OLIMJANOV OTABEK LUXMONJON O‘G‘LI","ORTIQBOYEVA SEVINCHOY NODIRBEK QIZI","SOBIRJONOVA MUBINA ZOKIRJON QIZI","SOLIYEV DOSTONBEK RUSTAMOVICH","SOLIYEV SARDORBEK YODGORJON O‘G‘LI","TOSHPULATOV MANSURALI ANVARJON O‘G‘LI","TULQINBOYEV JASURBEK FARXOD O‘G‘LI","TURG‘UNBOYEVA PARIZODA OCHILBEK QIZI","TURGUNOVA RAYXONA ALISHER QIZI","TURSUNBAYEV FIRDAVSBEK ADXAMJON O‘G‘LI","XAYRULLAVA MADINABONU XABIBILLO QIZI","XAKIMOVA KAMOLA SHUXRATJON QIZI","XOLMIRZAYEVA MUBINA MUZAFFAR QIZI","XOMITXONOV JAMSHIDBEK ISMOILJON O‘G‘LI","XUDAYNAZAROVA SARVINOZ RO‘ZIMAMATOVNA","SHOKIROVA IRODAXON BEKZODJONOVNA","ERGASHEVA OZODAXON RAVSHANBEK QIZI"],"9-B":["ABDIXALILOVA MOHICHEXRABONU XAMIDILLO QIZI","ABDUVOXIDOVA MUMTOZBEGIM ABDUBANNO QIZI","ABDUQAXXAROV KAMOLBEK MURODJON O‘G‘LI","ABDULHAMIDOVA ZIYODA RAVSHANBEK QIZI","ABDUMALIKOV BAXODIR ABDULXAKIM O‘G‘LI","AKRAMJANOVA SHAHLO SOBIRJON QIZI","AXMADALIYEV AZIZBEK ALISHER O‘G‘LI","AXMADJONOV RIVOJIDDIN ADXAMJON O‘G‘LI","AXMADJONOVA GULCHIROY ANVARJON QIZI","AXMADOV ABDULLOH ADXAMJON O‘G‘LI","VALIJONOV DIYORBEK OTABEK O‘G‘LI","KOMILJONOV AZIZBEK AZIMJON O‘G‘LI","QODIRJONOV SHAXRIYOR SHAVKATJON O‘G‘LI","MAMAJANOV ZILOLA BAXTIYOR QIZI","MAXAMMATJONOV ZOXIDJON ZOKIRJON O‘G‘LI","MAXMADJONOV SUXROBBEK MA‘RUFJON O‘G‘LI","MAXMUDJONOV MUSTAFO OLIMJON O‘G‘LI","MUXAMADMUSOYEV BAXTIYOR OTABEK O‘G‘LI","MUXAMMADISMOILOV MUXAMMADMUSTAFO","NOMONJONOV AXRORBEK ADXAMJON O‘G‘LI","RAXIMJONOVA SHODIYAXON AXMADJON QIZI","RUZMAMATOVA RAYXONA MURODOVNA","RUSTAMJANOV ULUG‘BEK ABDURASHID O‘G‘LI","SOBIROVA FERUZA XURSHID QIZI","TURABOYEVA MARJONA MA‘MUR QIZI","TURAXONOVA SHAHINABONU ISROILJON QIZI","TUXTABAYEVA MADINABONU BAXTIYOR QIZI","XASANBOYEVA ZUHRA BAXROMJON QIZI","XASANBOYEVA FOTIMA BAXROMJON QIZI","ERGASHEV NURMUHAMMAD BAXTIYOR O‘G‘LI","YULCHIBAYEV KAMRONBEK SARDOR O‘G‘LI"],"9-D":["ABDIXALILOVA FARANGIZ ABDUJALIL QIZI","ABDUVOHIDOVA MADINABONU SIROJIDDIN QIZI","AXMEDOV OG‘ABEK SHAVKATJON O‘G‘LI","DAVLATALIYEVA MADINA QILICHBEK QIZI","DAVRONBEKOV ASADBEK ASILJON O‘G‘LI","JURABOYEV RUSTAMJON RAXIMJON O‘G‘LI","ZOKIRJONOVA ZUXRAXON AKBARJON QIZI","ZOKIRJONOVA FOTIMAXON AKBARJON QIZI","IBRAGIMJONOV AXMADJON UKTAMJONOVICH","IKROMOV INOMJON ILXOMJON O‘G‘LI","ILXOMJONOVA MUNISA ALISHER QIZI","ISLOMJONOV UMIDJON UKTAMJON O‘G‘LI","KENJABAYEVA GULBAXOR BAXRIDDIN QIZI","RUZIBAYEV QUVONCHBEK BEXZOD O‘G‘LI","SOBIRJANOV ANVARJON MASHRABJON O‘G‘LI","TOXIRJONOV JASURBEK TOXIRJON O‘G‘LI","TOXIRJONOVA MALIKA ALISHER QIZI","TO‘LQINJONOV ULUG‘BEK IZZATULLA O‘G‘LI","TURSUNBOYEVA GO‘ZAL AKMAL QIZI","TURSUNPULATOVA MOXINUR AXADJON QIZI","USMONJONOV TEMURBEK BAXRIDDIN O‘G‘LI","XAKIMJANOV ISLOM ILXOM O‘G‘LI","XAMRAYEV IBROXIM KOMILJON O‘G‘LI","XASANBOYEVA MUSHTARIYBONU DILMUROD QIZI","XOJIDEDAYEV SHAHZODBEK SHUHRAT O‘G‘LI","XOTAMJONOV SHAXRIYOR DONIYOR O‘G‘LI","SHAMSIDDINOV SANJARBEK SADRIDDIN O‘G‘LI","SHOKIRJONOVA BARNOXON SHARIFJON QIZI","ERGASHBAYEV SHOXJAXON XUSAN O‘G‘LI"],"9-E":["ABDUG‘ANIYEVA RAYXONA ABDUJABBOR QIZI","ABDUJALILOV FIRDAVS ABDUMALIK O‘G‘LI","ABDUMUMINOV ARABBOY ABROR O‘G‘LI","ABDUFATTOXOVA NIGINA OLTINBEK QIZI","ADASHALIYEVA GULSANAM MUXAMMADZOKIR QIZI","AXMADJANOVA NIGINABONU XASAN QIZI","A‘LOXO‘JAYEVA DILNOZA ANVARJON QIZI","G‘ULOMJONOV ABDULVOSIT TOHIRJON O‘G‘LI","JURABOYEV ELDOR XASANOVICH","QAMOLDINOV AXMADBEK AKRAMJON O‘G‘LI","QODIRJONOV BEKZOD FOZILJONOVICH","QOSIMBOYEV YAXYOBEK BAXODIR O‘G‘LI","MAXAMMADJONOV ABDURAXMON BAXTIYOR O‘G‘LI","ODILJONOVA MUSHTARIYBONU SOXIBJON QIZI","RAXIMJANOVA SHAXINABONU MUZAFFAR QIZI","RAXMATILLAYEV OYBEK XAMIDILLO O‘G‘LI","RUSTAMJONOVA DIYORABEGIM DOSTONJON QIZI","SOLIJONOVA SEVINCH KOZIMJON QIZI","TOJIMIRZAYEVA SHAXZODA XUSANBOY QIZI","UBAYDULLAYEV BEXRUZBEK JAXONGIR O‘G‘LI","O‘RAZMATOVA GULNOZA AZAMAT QIZI","XAMITBOYEV JOXONGIR USMIRJON O‘G‘LI","XASANBOYEVA RUXSORA ADXAMJON QIZI","XOLIQOV SHOXJAXON ABDURASHID O‘G‘LI","SHAVKATOVA HUSNIDA NOSIR QIZI","ERGASHBOYEV SUHROBJON SOXIBJON O‘G‘LI","YUSUFXODJAYEVA RUKIYAXON XAMIDJON QIZI"],"10-A":["ABDUNABIYEVA MUNISAXON MIRZOXID QIZI","ABDUVALIYEV ABRORJON ADXAMJON O‘G‘LI","AXMADJANOVA MARJONA BUNYODJON QIZI","ERGASHBOYEVA MADINABONU ODILBEK QIZI","ERGASHEVA KUMUSHBIBI TUXTABOY QIZI","ERKINOVA XONZODAXON DILSHOD QIZI","IBRAGIMOVA DILAFRUZ XASANBOY QIZI","IKROMJONOV AKBARJON AKRAMJON O‘G‘LI","JURAXANOVA DURDONAXON ULUG‘BEK QIZI","MAXAMADOVA MUBINAXON SODIQJON QIZI","MAXMADJONOV FAZLIDDIN AKBAR O‘G‘LI","MURODILLAYEVA E‘ZOZAXON DILSHODBEK QIZI","RUSTAMOVA RUXSHONA BOTIRQIZI","SHAMSIDDINOVA OYDINA RAXIMJON QIZI","SHERMAMATOV NURMUHAMMAD BAXROMJON O‘G‘LI","VOXIDJANOVA MUSHTARIYBONU BEGZOD QIZI","XOLMIRZAYEVA BARCHINOY BAXTIYOR QIZI"],"10-B":["ABDUG‘APPOROVA BARCHINOY ABDURASHID QIZI","ABDULXAMIDOVA DILSHODA MUZAFFAR QIZI","ABDUQODIROV SHERMUHAMMAD MAXMUDJON O‘G‘LI","ABDUVAXOBOVA NOZANIN SHUXRATJON QIZI","AKRAMJONOVA MAHLIYOXON ANVARJON QIZI","AKRAMOVA OYDINA AKMALJON QIZI","BEKMIRZAYEVA DURDONA ELMUROD QIZI","DEDABAYEVA GULMIRAXON DILSHOD QIZI","ERGASHBOYEVA SABRINA XASANBOY QIZI","IBROXIMOVA MUXAYYOXON ISOQJON QIZI","ISMONJANOVA GO‘ZALXON FARXOD QIZI","ISMONJONOV IXLOSBEK ILXOMJON O‘G‘LI","MAHMUDJONOVA DILNOZA ADHAMJON QIZI","MAXAMADIBROXIMOVA MARJONA ABDURASUL QIZI","O‘ROLOV AKOBIR AZAMATOVICH","ORTIQBAYEVA GULYORA ALIMARDON QIZI","RUSTAMOVA MUSHTARIY BAXTIYOR QIZI","SHERMIRZAYEVA RUXSHONA SHERZOD QIZI","TOXIROV MIRZIYO MIRZOHID O‘G‘LI","TURSUNBOYEVA MUQADDASXON SHOKIRJON QIZI","UMARJONOVA DILNAVOZ NODIRJON QIZI","XAMDAMOVA AZIZA ALIMARDON QIZI","XIKMATILLAYEVA MUBINA OYOSBOY QIZI"],"11-A":["ABDUG‘ANIYEV ADHAMJON MUZAFFAR O‘G‘LI","ABDUKARIMOV AZAMJON MAVLONBOY O‘G‘LI","BAXROMJANOV IQBOLJON SALIMJON O‘G‘LI","BOZORBOYEVA MADINABONU SHUHRATJON QIZI","G‘OFURJONOVA GULRUX G‘ULOMJON QIZI","ISOQJANOVA MUSHTARIYBONU BAXTIYOR QIZI","ISOQJONOVA NODIRA QODIRJON QIZI","LUTFILLAYEVA INOYATBONU NOSIRJON QIZI","MAMADALIYEVA DURDONA DILMUROD QIZI","RAXIMOVA XOSILA ILXOMJON QIZI","RUSTAMOVA MUNIRA NOZIMJON QIZI","TURSUNBOYEVA SARVINOZ NODIRBEK QIZI","USMONJONOVA MASHHURAXON BAXRIDDIN QIZI","XASANBOYEVA MARJONA ADHAMJON QIZI","XOSHIMJONOV NURBEK ELYORJON O‘G‘LI","AHMADJONOV ZOYIRJON A‘ZAMJON O‘G‘LI","BOQIJONOVA BIBIRUXSORA OBIDJON QIZI","G‘OFUROV JALOLIDDIN JAMOLIDDIN O‘G‘LI","MAMAJANOVA MADINABONU SAYFIDDIN QIZI","MAXAMMATJONOV FAXRIDDIN FARXODJON O‘G‘LI","MAXMADJONOVA MUBINAXON XABIBULLO QIZI","MASHRABJONOVA XILOLAXON MAXMUDJON QIZI","MUMINJONOVA GULZODA ORIFJON QIZI","NOMONJONOVA KUMUSHOY A‘ZAMJON QIZI","OLIMJANOVA DILSHODA ANVAR QIZI","SAIDJALOLOV MIRJALOL MUZAFFAR O‘G‘LI","UMARALIYEVA SHABBONA DILSHOD QIZI","ERKINBOYEVA FARZONA ILXOM QIZI"],"11-B":["ERKINOV AZIZBEK MUXIDDINOVICH","ABDUNABIYEV OTABEK AVAZBEK O‘G‘LI","ABDUXALILOVA KUMUSHXON AKRAMJON QIZI","AKBARALIYEV AZIZBEK BAXROMJON O‘G‘LI","AHMADALIYEVA MARHABO NAZIRJON QIZI","AHMADJONOVA ZULAYXO MAXMUDJON QIZI","JALOLXANOVA DIYORA SANJARBEK QIZI","ZOKIRJONOVA SHOXSANAMXON SHOKIRJON QIZI","INOMADINOVA XANIFAXON IKROMJON QIZI","KOMILJONOVA MAHLIYO ILHOMJON QIZI","MAMADSHOYEVA MUXTARAM MAMAJON QIZI","MAHAMATJONOVA MUHAYYO RUSTAMJON QIZI","MURATOVA DILAFRO‘Z XAYATULLO QIZI","NURMAMATOV JAVOHIR BAXODIR O‘G‘LI","ORTIQALIYEVA ASAL BAXTIYOR QIZI","OTAXONOVA MUXTASAR SHOKIRJON QIZI","TOJIMAMATOVA NOILAXON ABDULLAJON QIZI","TOSHTEMIROVA MUMTOZBEGIM RAVSHANBEK QIZI","TULQINBOYEV JAMSHIDBEK FARXOD O‘G‘LI","TULQINBOYEVA SAYYORA SUR‘AT QIZI","UMARXONOVA MOXINISOBEGIM SHUKRULLO QIZI","XAKIMOV MIRXAYOT SHERZOD O‘G‘LI","XASANBOYEV AXADJON AKMALJON O‘G‘LI","SHARIFBOYEV ISABEK ZOKIRJON O‘G‘LI","YUSUVALIYEVA OYDINA ORIFJON QIZI","YUSUPOVA MUSHARRAF HABIBULLO QIZI"]};
let all = [], earlyRecords = [], col = null, earlyCol = null, mode = "local", excused = null, clearTimer = null, earlyPhotoData = "";
const LS = "kech_qolganlar_v2";
const EARLY_LS = "early_departures_v1";
let earlyPhotoDbPromise = null;

function openEarlyPhotoDb() {
  if (!window.indexedDB) return Promise.reject(new Error("Brauzer suratlarni saqlashni qo‘llamaydi."));
  if (!earlyPhotoDbPromise) {
    earlyPhotoDbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open("davomat_early_photos", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("photos");
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(new Error("Suratlarni saqlash omborini ochib bo‘lmadi."));
    }).catch(err => { earlyPhotoDbPromise = null; throw err; });
  }
  return earlyPhotoDbPromise;
}
async function storeEarlyPhoto(key, photo, action) {
  const db = await openEarlyPhotoDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("photos", action === "get" ? "readonly" : "readwrite");
    const store = tx.objectStore("photos");
    const request = action === "put" ? store.put(photo, key) : action === "delete" ? store.delete(key) : store.get(key);
    let result;
    request.onsuccess = () => { result = request.result; };
    request.onerror = () => reject(new Error("Hujjat suratiga murojaat qilib bo‘lmadi."));
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(new Error("Hujjat suratini saqlab bo‘lmadi."));
    tx.onabort = () => reject(new Error("Hujjat suratini saqlash bekor qilindi."));
  });
}

function loadEarlyLocal() {
  try { earlyRecords = JSON.parse(localStorage.getItem(EARLY_LS) || "[]") || []; }
  catch (e) { earlyRecords = []; $("earlyMsg").textContent = "Erta ketganlar ma’lumotini o‘qib bo‘lmadi."; $("earlyMsg").className = "msg err"; }
}
function saveEarlyLocal() { localStorage.setItem(EARLY_LS, JSON.stringify(earlyRecords)); }

function loadLocal() {
  try {
    all = JSON.parse(localStorage.getItem(LS) || "[]") || [];
    if (!all.length) {
      const old = JSON.parse(localStorage.getItem("kech_qolganlar_v1") || "{}") || {};
      Object.keys(old).forEach(d => old[d].forEach(s => all.push(Object.assign({}, s, { date: d }))));
    }
  } catch (e) { all = []; }
}
function saveLocal() { try { localStorage.setItem(LS, JSON.stringify(all)); } catch (e) {} }
function setState() {
  $("dbstate").textContent = mode === "db" ? "Ma’lumotlar bazasi: umumiy, barcha qurilmalarda bir xil." : "Ma’lumotlar bazasi: faqat shu qurilmada saqlanadi.";
}
function say(t, err) { const m = $("msg"); m.textContent = t; m.className = "msg" + (err ? " err" : ""); }

async function addRec(r) {
  r.id = Date.now() + "" + Math.floor(Math.random() * 1000);
  if (mode === "db") await col.doc(r.id).set(r);
  else { all.push(r); saveLocal(); render(); }
}
async function delRec(id) {
  if (mode === "db") await col.doc(id).delete();
  else { all = all.filter(r => r.id !== id); saveLocal(); render(); }
}
async function clearDay(day) {
  if (mode === "db") await Promise.all(all.filter(r => r.date === day).map(r => col.doc(r.id).delete()));
  else { all = all.filter(r => r.date !== day); saveLocal(); render(); }
}
async function addEarlyRec(r) {
  r.id = Date.now() + "" + Math.floor(Math.random() * 1000);
  if (mode === "db") await earlyCol.doc(r.id).set(r);
  else {
    const photo = r.photo || "";
    if (photo) await storeEarlyPhoto(r.id, photo, "put");
    const record = { id: r.id, name: r.name, cls: r.cls, date: r.date, time: r.time, note: r.note };
    if (photo) record.photoKey = r.id;
    earlyRecords.push(record);
    try { saveEarlyLocal(); } catch (e) {
      earlyRecords.pop();
      if (photo) await storeEarlyPhoto(r.id, null, "delete");
      throw e;
    }
    renderEarlyList();
  }
}
async function delEarlyRec(id) {
  if (mode === "db") await earlyCol.doc(id).delete();
  else {
    const previous = earlyRecords;
    earlyRecords = earlyRecords.filter(r => r.id !== id);
    try { saveEarlyLocal(); } catch (e) { earlyRecords = previous; throw e; }
    await storeEarlyPhoto(id, null, "delete");
    renderEarlyList();
  }
}
function pdate(s) { const a = s.split("-").map(Number); return new Date(a[0], a[1] - 1, a[2]); }
function ymd(t) { return t.getFullYear() + "-" + pad(t.getMonth() + 1) + "-" + pad(t.getDate()); }
function weekStart(d) { const t = pdate(d); t.setDate(t.getDate() - ((t.getDay() + 6) % 7)); return ymd(t); }
function weekEnd(d) { const t = pdate(weekStart(d)); t.setDate(t.getDate() + 6); return ymd(t); }
const wkKey = r => keyOf(r) + "#" + weekStart(r.date);
function counts() { const c = {}, run = {}, fr = {}; all.slice().sort((a, b) => (a.date + a.time + a.id < b.date + b.time + b.id ? -1 : 1)).forEach(r => { const k = wkKey(r); run[k] = (run[k] || 0) + 1; c[r.id] = run[k]; if (r.excused === true) c["f" + r.id] = 0; else { fr[k] = (fr[k] || 0) + 1; c["f" + r.id] = fr[k]; } }); return c; }

function reasonCell(s) {
  if (s.excused === true) return "<span class='tag yes'>Sababli · jarimasiz</span>" + (s.reasonText ? " " + esc(s.reasonText) : "");
  if (s.excused === false) return "<span class='tag no'>Sababsiz</span>";
  return "—";
}
function setExcused(v) {
  excused = v;
  $("yes").className = "ghost" + (v === true ? " on-yes" : "");
  $("no").className = "ghost" + (v === false ? " on-no" : "");
  $("reasonText").hidden = $("chips").hidden = v !== true;
}

function render() {
  const day = $("date").value, cnt = counts();
  const list = all.filter(r => r.date === day).sort((a, b) => (a.time < b.time ? -1 : 1));
  $("count").textContent = "Jami: " + list.length;
  $("empty").style.display = list.length ? "none" : "block";
  $("rows").innerHTML = list.map((s, i) => {
    const n = cnt[s.id];
    return "<tr><td class='n'>" + (i + 1) + "</td><td class='name'>" + esc(s.name) + (cnt["f" + s.id] >= FINE_THRESHOLD ? "<span class='fine'>JARIMA</span>" : "") + "<span class='wk'>hafta: " + n + "</span>" +
      "</td><td class='c'>" + esc(s.cls) + "</td><td class='t'>" + fmtD(s.date) + " " + s.time +
      "</td><td class='why'>" + reasonCell(s) + "</td><td class='act'><button class='del' data-id='" + s.id + "'>O’chirish</button></td></tr>";
  }).join("");

  const groups = {};
  all.filter(r => r.excused !== true && (selWeek === "all" || weekStart(r.date) === selWeek)).forEach(r => { const k = wkKey(r); (groups[k] = groups[k] || []).push(r); });
  const fines = Object.values(groups).filter(g => g.length >= FINE_THRESHOLD).sort((a, b) => (weekStart(a[0].date) < weekStart(b[0].date) ? 1 : weekStart(a[0].date) > weekStart(b[0].date) ? -1 : b.length - a.length));
  $("fines").innerHTML = fines.length ? fines.map(g =>
    "<div class='fr'><b>" + esc(g[0].name) + "</b> · " + esc(g[0].cls) + " <span class='fine'>JARIMA</span><span class='wk'>hafta: " + g.length + "</span><small>Hafta: " + fmtD(weekStart(g[0].date)) + " – " + fmtD(weekEnd(g[0].date)) + " · Sanalar: " +
    g.map(r => fmtD(r.date) + " " + r.time).sort().join(", ") + "</small></div>").join("") : "<div class='empty'>Hozircha jarimaga tortilganlar yo’q.</div>";
  renderAll(cnt);
  renderStats();
  weekCheck();
}

function renderAll(cnt) {
  const cw = weekStart(today());
  const wks = Array.from(new Set(all.map(r => weekStart(r.date)).concat([cw]))).sort().reverse();
  if (selWeek !== "all" && wks.indexOf(selWeek) < 0) selWeek = cw;
  $("wsel").innerHTML = wks.map(w => "<option value='" + w + "'>" + fmtD(w) + " – " + fmtD(weekEnd(w)) + (w === cw ? " (joriy hafta)" : "") + "</option>").join("") + "<option value='all'>Barcha haftalar</option>";
  $("wsel").value = selWeek;
  const list = all.filter(r => selWeek === "all" || weekStart(r.date) === selWeek).sort((a, b) => (a.date + a.time < b.date + b.time ? 1 : -1));
  $("allcount").textContent = "Jami yozuvlar: " + list.length;
  let html = "", cur = "";
  list.forEach(s => {
    if (s.date !== cur) { cur = s.date; html += "<div class='dh'>" + fmtD(cur) + "</div>"; }
    const n = cnt[s.id];
    html += "<div class='ar'><div class='ai'><b>" + esc(s.name) + "</b>" + (cnt["f" + s.id] >= FINE_THRESHOLD ? "<span class='fine'>JARIMA</span>" : "") + "<span class='wk'>hafta: " + n + "</span><small> · " + esc(s.cls) + " · " + s.time + " · </small>" + reasonCell(s) + "</div><button class='del' data-id='" + s.id + "'>O’chirish</button></div>";
  });
  $("alllist").innerHTML = html || "<div class='empty'>Hali hech kim belgilanmagan.</div>";
}

$("date").value = today();
$("fdate").value = today();
$("time").value = nowStr();
$("today").onclick = () => { $("fdate").value = today(); refreshWheelDisplay("fdate"); };
$("now").onclick = () => { $("fdate").value = today(); $("time").value = nowStr(); refreshWheelDisplay("fdate"); refreshWheelDisplay("time"); };
$("yes").onclick = () => setExcused(true);
$("no").onclick = () => setExcused(false);

$("add").onclick = async () => {
  const name = $("name").value.trim(), cls = $("cls").value.trim();
  if (!cls) { say("Avval sinfni tanlang.", true); return; }
  if (!name) { say("O’quvchini sinf ro’yxatidan tanlang.", true); return; }
  if (excused === null) { say("Sababli yoki sababsizligini tanlang.", true); return; }
  const rec = { name, cls, date: $("fdate").value || today(), time: $("time").value || nowStr(), excused, reasonText: excused ? $("reasonText").value.trim() : "" };
  const n = all.filter(r => wkKey(r) === wkKey(rec) && r.excused !== true).length + 1;
  try { await addRec(rec); } catch (e) { say("Saqlab bo’lmadi. Ruxsat yoki internetni tekshiring.", true); return; }
  populateNames(); $("reasonText").value = "";
  setExcused(null); $("fdate").value = today(); $("time").value = nowStr(); $("name").focus();
  refreshWheelDisplay("fdate"); refreshWheelDisplay("time");
  $("date").value = rec.date; refreshWheelDisplay("date"); render();
  if (rec.excused !== true && n >= FINE_THRESHOLD) say(name + " shu hafta " + n + "-marta sababsiz kech qoldi — JARIMA!", true); else say(name + (rec.excused ? " sababli deb belgilandi — jarimasiz." : " belgilandi."));
};

$("rows").onclick = async e => {
  const id = e.target.dataset && e.target.dataset.id;
  if (!id) return;
  try { await delRec(id); } catch (err) { say("O’chirib bo’lmadi.", true); }
};

function resetClear() { clearTimeout(clearTimer); clearTimer = null; $("clear").textContent = "Kunni tozalash"; $("clear").style.color = ""; }
$("clear").onclick = async () => {
  const day = $("date").value;
  if (!all.some(r => r.date === day)) { say("Bu kunda tozalanadigan ro’yxat yo’q.", true); return; }
  if (!clearTimer) {
    $("clear").textContent = "Ha, tozalash";
    $("clear").style.color = "var(--danger)";
    clearTimer = setTimeout(() => { resetClear(); say(""); }, 4000);
    say("Tasdiqlash uchun tugmani yana bir marta bosing.", true);
    return;
  }
  resetClear();
  try { await clearDay(day); say(fmtD(day) + " ro’yxati tozalandi."); } catch (e) { say("Tozalab bo’lmadi.", true); }
};

$("date").onchange = () => { say(""); render(); };
$("name").addEventListener("keydown", e => { if (e.key === "Enter") $("add").click(); });
$("cls").addEventListener("keydown", e => { if (e.key === "Enter") $("add").click(); });

$("dl").onclick = async () => {
  const day = $("date").value, cnt = counts();
  const list = all.filter(r => r.date === day).sort((a, b) => (a.time < b.time ? -1 : 1));
  if (!list.length) { say("Yuklab olish uchun ro’yxat bo’sh.", true); return; }
  const lines = [["№", "F.I.SH", "Sinf", "Sana", "Kelgan vaqti", "Sabab holati", "Sabab", "Haftada kech qolish", "Jarima"]].concat(list.map((s, i) => {
    const n = cnt[s.id];
    return [i + 1, s.name, s.cls, fmtD(s.date), s.time, s.excused === true ? "Sababli" : s.excused === false ? "Sababsiz" : "", s.reasonText || "", n, cnt["f" + s.id] >= FINE_THRESHOLD ? "JARIMA" : ""];
  }));
  try {
    await downloadXlsx("kech_qolganlar_" + day + ".xlsx", makeXlsx(lines, "Kech qolganlar"));
    say("Fayl saqlandi.");
  } catch (err) {
    say(err && err.code === "declined" ? "Yuklab olish bekor qilindi." : "Yuklab olib bo’lmadi.", true);
  }
};

const norm = s => String(s).toLowerCase().replace(/[`'’‘ʻʼ]/g, "").replace(/\s+/g, " ").trim();
Object.keys(ROSTER).forEach(c => { const o = document.createElement("option"); o.value = c; o.textContent = c + " sinf (" + ROSTER[c].length + " ta)"; $("cls").appendChild(o); });
function populateNames() {
  const cls = $("cls").value, nameSelect = $("name");
  nameSelect.innerHTML = '<option value="">— O‘quvchini tanlang —</option>';
  if (!cls) { nameSelect.disabled = true; refreshWheelDisplay("name"); return; }
  const done = {};
  all.forEach(r => { if (r.date === today() && r.cls === cls) done[norm(r.name)] = true; });
  ROSTER[cls].forEach(name => {
    const option = document.createElement("option");
    option.value = name;
    option.textContent = name + (done[norm(name)] ? " — bugun belgilangan" : "");
    nameSelect.appendChild(option);
  });
  nameSelect.disabled = false;
  refreshWheelDisplay("name");
}
$("cls").addEventListener("change", populateNames);

Object.keys(ROSTER).forEach(c => {
  const o = document.createElement("option");
  o.value = c; o.textContent = c + " sinf (" + ROSTER[c].length + " ta)";
  $("earlyCls").appendChild(o);
});
function populateEarlyNames() {
  const cls = $("earlyCls").value, nameSelect = $("earlyName");
  nameSelect.innerHTML = '<option value="">— O‘quvchini tanlang —</option>';
  if (!cls) { nameSelect.disabled = true; refreshWheelDisplay("earlyName"); return; }
  ROSTER[cls].forEach(name => {
    const option = document.createElement("option");
    option.value = name; option.textContent = name;
    nameSelect.appendChild(option);
  });
  nameSelect.disabled = false;
  refreshWheelDisplay("earlyName");
}
$("earlyCls").addEventListener("change", populateEarlyNames);

function compressEarlyPhoto(file) {
  return new Promise((resolve, reject) => {
    const image = new Image(), url = URL.createObjectURL(file);
    image.onload = () => {
      URL.revokeObjectURL(url);
      const scale = Math.min(1, 1400 / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(image.naturalWidth * scale);
      canvas.height = Math.round(image.naturalHeight * scale);
      const context = canvas.getContext("2d");
      if (!context) { reject(new Error("Suratni tayyorlab bo‘lmadi.")); return; }
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(blob => {
        if (!blob) { reject(new Error("Suratni tayyorlab bo‘lmadi.")); return; }
        if (blob.size > 650000) { reject(new Error("Surat hajmi katta. Yaqinroq masofadan qayta suratga oling.")); return; }
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error("Suratni o‘qib bo‘lmadi."));
        reader.readAsDataURL(blob);
      }, "image/jpeg", 0.82);
    };
    image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Rasm formatini ochib bo‘lmadi.")); };
    image.src = url;
  });
}

async function renderEarlyList() {
  const day = $("earlyListDate").value;
  const list = earlyRecords.filter(r => r.date === day).sort((a, b) => (a.time < b.time ? -1 : 1));
  $("earlyCount").textContent = "Jami: " + list.length;
  $("earlyEmpty").style.display = list.length ? "none" : "block";
  let rows;
  try { rows = await Promise.all(list.map(async r => ({ record: r, photo: r.photo || (r.photoKey ? await storeEarlyPhoto(r.photoKey, null, "get") : "") }))); }
  catch (err) {
    $("earlyListMsg").textContent = err.message || "Suratlarni o‘qib bo‘lmadi.";
    $("earlyListMsg").className = "msg err";
    return;
  }
  if (day !== $("earlyListDate").value) return;
  $("earlyListMsg").textContent = "";
  $("earlyListMsg").className = "msg";
  $("earlyRows").innerHTML = rows.map((item, i) => {
    const r = item.record, photo = item.photo ? "<a href='" + esc(item.photo) + "' target='_blank' rel='noopener'><img class='early-photo-thumb' src='" + esc(item.photo) + "' alt='Hujjat surati'></a>" : "—";
    return "<tr><td class='n'>" + (i + 1) + "</td><td class='name'>" + esc(r.name) + "</td><td class='c'>" + esc(r.cls) + "</td><td class='t'>" + fmtD(r.date) + " " + esc(r.time) + "</td><td class='why'>" + esc(r.note || "—") + "</td><td>" + photo + "</td><td class='act'><button class='del' data-id='" + esc(r.id) + "'>O‘chirish</button></td></tr>";
  }).join("");
}

$("earlyPhotoBtn").onclick = () => $("earlyPhotoFile").click();
$("earlyPhotoFile").onchange = async e => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const msg = $("earlyMsg");
  msg.textContent = "Surat tayyorlanmoqda...";
  msg.className = "msg";
  try {
    earlyPhotoData = await compressEarlyPhoto(file);
    $("earlyPhotoPreview").src = earlyPhotoData;
    $("earlyPhotoPreview").hidden = false;
    msg.textContent = "Hujjat surati tayyor.";
  } catch (err) {
    earlyPhotoData = "";
    $("earlyPhotoPreview").removeAttribute("src");
    $("earlyPhotoPreview").hidden = true;
    msg.textContent = err.message || "Suratni tayyorlab bo‘lmadi.";
    msg.className = "msg err";
  }
};
$("earlyAdd").onclick = async () => {
  const name = $("earlyName").value, cls = $("earlyCls").value;
  if (!cls || !name) { $("earlyMsg").textContent = "Sinf va o‘quvchini tanlang."; $("earlyMsg").className = "msg err"; return; }
  const record = {
    name, cls, date: $("earlyDate").value || today(), time: $("earlyTime").value || nowStr(),
    note: $("earlyNote").value.trim(), photo: earlyPhotoData
  };
  try {
    await addEarlyRec(record);
    $("earlyListDate").value = record.date;
    refreshWheelDisplay("earlyListDate");
    renderEarlyList();
    $("earlyMsg").textContent = "Erta ketgan o‘quvchi qayd etildi.";
    $("earlyMsg").className = "msg";
    $("earlyPhotoFile").value = "";
    $("earlyPhotoPreview").removeAttribute("src");
    $("earlyPhotoPreview").hidden = true;
    $("earlyNote").value = "";
    earlyPhotoData = "";
  } catch (err) {
    $("earlyMsg").textContent = err.message || "Saqlab bo‘lmadi.";
    $("earlyMsg").className = "msg err";
  }
};
$("earlyListDate").onchange = renderEarlyList;
$("earlyRows").onclick = async e => {
  const id = e.target.dataset && e.target.dataset.id;
  if (!id) return;
  try { await delEarlyRec(id); } catch (err) {
    $("earlyListMsg").textContent = err.message || "O‘chirib bo‘lmadi.";
    $("earlyListMsg").className = "msg err";
  }
};
$("earlyDl").onclick = async () => {
  const day = $("earlyListDate").value;
  const list = earlyRecords.filter(r => r.date === day).sort((a, b) => (a.time < b.time ? -1 : 1));
  const msg = $("earlyListMsg");
  if (!list.length) { msg.textContent = "Yuklab olish uchun ro‘yxat bo‘sh."; msg.className = "msg err"; return; }
  try {
    if (typeof ExcelJS === "undefined") throw new Error("Excel rasm kutubxonasi yuklanmadi.");
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet("Erta ketganlar");
    sheet.columns = [
      { header: "№", key: "number", width: 6 }, { header: "F.I.SH.", key: "name", width: 34 },
      { header: "Sinf", key: "class", width: 10 }, { header: "Sana", key: "date", width: 14 },
      { header: "Ketgan vaqti", key: "time", width: 14 }, { header: "Izoh", key: "note", width: 28 },
      { header: "Hujjat surati", key: "photo", width: 18 }
    ];
    for (let i = 0; i < list.length; i++) {
      const r = list[i];
      const row = sheet.addRow({ number: i + 1, name: r.name, class: r.cls, date: fmtD(r.date), time: r.time, note: r.note || "" });
      row.height = 58;
      const photo = r.photo || (r.photoKey ? await storeEarlyPhoto(r.photoKey, null, "get") : "");
      if (r.photoKey && !photo) throw new Error("Hujjat suratlaridan biri topilmadi.");
      if (photo) {
        const imageId = workbook.addImage({ base64: photo, extension: "jpeg" });
        sheet.addImage(imageId, { tl: { col: 6, row: row.number - 1 }, ext: { width: 94, height: 72 } });
      }
    }
    sheet.getRow(1).font = { bold: true };
    const data = await workbook.xlsx.writeBuffer();
    await downloadXlsx("erta_ketganlar_" + day + ".xlsx", data);
    msg.textContent = "Excel fayli, mavjud hujjat suratlari bilan, saqlandi.";
    msg.className = "msg";
  } catch (err) {
    msg.textContent = err.message || "Excel faylini tayyorlab bo‘lmadi.";
    msg.className = "msg err";
  }
};

$("earlyDate").value = today();
$("earlyTime").value = nowStr();
$("earlyListDate").value = today();
$("earlyToday").onclick = () => { $("earlyDate").value = today(); refreshWheelDisplay("earlyDate"); };
$("earlyNow").onclick = () => { $("earlyDate").value = today(); $("earlyTime").value = nowStr(); refreshWheelDisplay("earlyDate"); refreshWheelDisplay("earlyTime"); };
initAndroidWheelPickers();
loadEarlyLocal();
renderEarlyList();

const EXAMPLES = ["Kasal bo’lib qolgan", "Shifokor qabulida bo’lgan", "Transport kechikdi", "Yo’lda tirbandlik / avariya", "Qor-yomg’ir, yo’l yopilgan", "Uyda favqulodda holat", "Ota-onasi maktabga olib keldi"];
$("chips").innerHTML = EXAMPLES.map(t => '<button type="button" class="ghost" data-t="' + t + '">' + t + "</button>").join("");
$("chips").onclick = e => { const t = e.target.dataset && e.target.dataset.t; if (t) $("reasonText").value = t; };

function renderStats() {
  const day = today(), cw = weekStart(day), td = all.filter(r => r.date === day);
  $("stToday").textContent = td.length;
  $("stYes").textContent = td.filter(r => r.excused === true).length;
  $("stNo").textContent = td.filter(r => r.excused !== true).length;
  const tally = list => { const c = {}; list.forEach(r => { const k = r.cls || "—"; c[k] = (c[k] || 0) + 1; }); return Object.keys(c).map(k => [k, c[k]]).sort((a, b) => b[1] - a[1]); };
  const wk = tally(all.filter(r => weekStart(r.date) === cw)), al = tally(all);
  $("topCls").innerHTML = wk.length ? "Bu hafta eng ko’p kech qolgan sinf: <b>" + esc(wk[0][0]) + "</b> (" + wk[0][1] + " marta)" : "Bu hafta hali kech qolgan yo’q.";
  $("rank").innerHTML = wk.slice(0, 5).map((x, i) => "<div class='rk'><span>" + (i + 1) + ". " + esc(x[0]) + "</span><b>" + x[1] + "</b></div>").join("") +
    (al.length ? "<div class='rk rk-total'><span>Barcha vaqt bo’yicha eng ko’p:</span><span>" + esc(al[0][0]) + " (" + al[0][1] + ")</span></div>" : "");
}

let selWeek = weekStart(today()), lastCW = selWeek, autoTried = {};
$("wsel").onchange = () => { selWeek = $("wsel").value; render(); };

function exportedWeeks() { try { return JSON.parse(localStorage.getItem("kech_exported") || "[]") || []; } catch (e) { return []; } }
function pendingWeeks() {
  const cur = weekStart(today()), ex = exportedWeeks();
  return Array.from(new Set(all.map(r => weekStart(r.date)))).filter(w => w < cur && ex.indexOf(w) < 0).sort();
}
async function exportWeek(w) {
  const m = $("wkmsg"), cnt = counts();
  const list = all.filter(r => weekStart(r.date) === w).sort((a, b) => (a.date + a.time < b.date + b.time ? -1 : 1));
  const rows = [["№", "F.I.SH", "Sinf", "Sana", "Kelgan vaqti", "Sabab holati", "Sabab", "Haftada kech qolish", "Jarima"]].concat(list.map((s, i) =>
    [i + 1, s.name, s.cls, fmtD(s.date), s.time, s.excused === true ? "Sababli" : s.excused === false ? "Sababsiz" : "", s.reasonText || "", cnt[s.id], cnt["f" + s.id] >= FINE_THRESHOLD ? "JARIMA" : ""]));
  try {
    await downloadXlsx("hafta_" + w + "_" + weekEnd(w) + ".xlsx", makeXlsx(rows, "Hafta"));
    const ex = exportedWeeks(); ex.push(w);
    try { localStorage.setItem("kech_exported", JSON.stringify(ex)); } catch (e) {}
    m.textContent = ""; weekCheck();
  } catch (err) {
    m.textContent = err && err.code === "declined" ? "Yuklab olish bekor qilindi. Tugma orqali qayta urinib ko’ring." : "Yuklab olib bo’lmadi. Tugma orqali qayta urinib ko’ring.";
  }
}
function weekCheck() {
  const p = pendingWeeks(), b = $("wkbanner");
  if (!p.length) { b.hidden = true; return; }
  const w = p[0], n = all.filter(r => weekStart(r.date) === w).length;
  $("wktext").textContent = "O’tgan hafta (" + fmtD(w) + " – " + fmtD(weekEnd(w)) + ") ro’yxati yuklab olinmagan. Yozuvlar: " + n + " ta.";
  b.hidden = false;
  if (!autoTried[w]) { autoTried[w] = true; exportWeek(w); }
}
$("wkbtn").onclick = () => { const p = pendingWeeks(); if (p.length) exportWeek(p[0]); };
setInterval(() => {
  const cw = weekStart(today());
  if (cw !== lastCW) { if (selWeek === lastCW) selWeek = cw; lastCW = cw; $("date").value = today(); $("fdate").value = today(); refreshWheelDisplay("date"); refreshWheelDisplay("fdate"); render(); }
  else { weekCheck(); renderStats(); }
}, 60000);

$("alllist").onclick = async e => {
  const id = e.target.dataset && e.target.dataset.id;
  if (!id) return;
  try { await delRec(id); } catch (err) { const m = $("msg2"); m.textContent = "O’chirib bo’lmadi."; m.className = "msg err"; }
};

$("dlall").onclick = async () => {
  const say2 = (t, err) => { const m = $("msg2"); m.textContent = t; m.className = "msg" + (err ? " err" : ""); };
  const cnt = counts();
  const list = all.filter(r => selWeek === "all" || weekStart(r.date) === selWeek).sort((a, b) => (a.date + a.time < b.date + b.time ? -1 : 1));
  if (!list.length) { say2("Yuklab olish uchun ro’yxat bo’sh.", true); return; }
  const lines = [["№", "F.I.SH", "Sinf", "Sana", "Kelgan vaqti", "Sabab holati", "Sabab", "Haftada kech qolish", "Jarima"]].concat(list.map((s, i) => {
    const n = cnt[s.id];
    return [i + 1, s.name, s.cls, fmtD(s.date), s.time, s.excused === true ? "Sababli" : s.excused === false ? "Sababsiz" : "", s.reasonText || "", n, cnt["f" + s.id] >= FINE_THRESHOLD ? "JARIMA" : ""];
  }));
  try {
    await downloadXlsx(selWeek === "all" ? "kech_qolganlar_hammasi.xlsx" : "hafta_" + selWeek + "_" + weekEnd(selWeek) + ".xlsx", makeXlsx(lines, "Kech qolganlar"));
    say2("Fayl saqlandi.");
  } catch (err) {
    say2(err && err.code === "declined" ? "Yuklab olish bekor qilindi." : "Yuklab olib bo’lmadi.", true);
  }
};

loadLocal(); setState(); render();
checkAppUpdate();
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) checkAppUpdate();
});
(async () => {
  try {
    const db = await claude.use("db");
    if (!db) return;
    col = db.collection("late"); earlyCol = db.collection("early_departures"); mode = "db"; setState();
    col.onSnapshot(s => { all = s.docs.map(d => Object.assign({}, d.data(), { id: d.id })); render(); },
      () => { mode = "local"; col = null; earlyCol = null; loadLocal(); loadEarlyLocal(); setState(); render(); renderEarlyList(); });
    earlyCol.onSnapshot(s => { earlyRecords = s.docs.map(d => Object.assign({}, d.data(), { id: d.id })); renderEarlyList(); },
      () => { mode = "local"; col = null; earlyCol = null; loadLocal(); loadEarlyLocal(); setState(); render(); renderEarlyList(); });
  } catch (e) {}
})();

const clockEl = document.getElementById("liveClock");
function updateLiveClock(){ if(clockEl){ const d=new Date(); const p=n=>String(n).padStart(2,"0"); clockEl.textContent=p(d.getDate())+"."+p(d.getMonth()+1)+"."+d.getFullYear()+" | "+p(d.getHours())+":"+p(d.getMinutes())+":"+p(d.getSeconds()); } }
updateLiveClock(); setInterval(updateLiveClock,1000);
