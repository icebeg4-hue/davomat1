from PIL import Image

im = Image.open("icons/icon-512.png").convert("RGBA")
sizes = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

for directory, size in sizes.items():
    resized = im.resize((size, size), Image.Resampling.LANCZOS)
    base = "android/app/src/main/res/" + directory + "/"
    resized.save(base + "ic_launcher.png")
    resized.save(base + "ic_launcher_round.png")
    resized.save(base + "ic_launcher_foreground.png")
